-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2021 at 10:24 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event`
--

-- --------------------------------------------------------

--
-- Table structure for table `accepted`
--

CREATE TABLE `accepted` (
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nid` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `college` varchar(225) NOT NULL,
  `school` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accepted`
--

INSERT INTO `accepted` (`fname`, `lname`, `tel`, `email`, `nid`, `age`, `college`, `school`, `department`, `year`) VALUES
('vvv', 'vvv', '555', 'karenzi@gmail.com', 'ffff', 'ffff', 'fff', 'fff', 'fff', 'fff'),
('NISHIMWE ', 'Naomie', '078524626', 'naomini@gmail.com', '11995556256555', '23', 'hhdd', 'jdjdj', 'dhjdjd', 'hdhd'),
('11995556256555', 'null', 'null', 'null', 'null', 'null', 'null', 'null', 'null', 'null'),
('uwicyeza', 'pamella', '1', 'karenzi@gmail.com', '1', '21', 'cst', 'cst', 'cst', 'cst'),
('UWICYEZA ', 'Pamella', '078524626', 'naomini@gmail.com', '11995556256555', '23', 'hhdd', 'jdjdj', 'dhjdjd', 'hdhd'),
('Faustin`', 'Irumva', '45445455454', 'fasutin@gmail.com', '1200080050154165', '23', 'cst', 'ict', 'dfd', 'fdf');

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nid` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `college` varchar(255) NOT NULL,
  `school` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`fname`, `lname`, `tel`, `email`, `nid`, `age`, `college`, `school`, `department`, `year`) VALUES
('Faustin`', 'Irumva', '45445455454', 'fasutin@gmail.com', '1200080050154165', '23', 'cst', 'ict', 'dfd', 'fdf'),
('Faustin`', 'Irumva', '45445455454', 'fasutin@gmail.com', '1200080050154165', '23', 'cst', 'ict', 'dfd', 'fdf');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rpassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`name`, `email`, `password`, `rpassword`) VALUES
('admin', 'admin@123', '123', '123'),
('null', 'gfgf@jdj', 'null', 'null'),
('null', 'null', 'null', 'null'),
('null', 'null', 'null', 'null');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
